# Permanent-deposition checklist

1. Upload the **unchanged** `X_THGNN_Reproduction_Anonymous_v1.zip` to Zenodo,
   OSF, or an institutional repository that supplies a persistent versioned URL.
2. During double-anonymous review, use an anonymous record and omit author,
   affiliation, ORCID, acknowledgements, and other identifying metadata. Add
   the final author metadata only after peer review, if the journal permits it.
3. Suggested resource type: dataset/software supplementary material.
4. Suggested keywords: X-THGNN; provenance graphs; reproducibility audit;
   enterprise attack detection; explainable GNN; negative results.
5. Suggested license for original archive material: the chosen project license.
   Upstream source files remain governed by the licenses reproduced in `licenses/`.
6. Publish the record, then replace `[INSERT AFTER DEPOSITION]` in the manuscript
   with the issued DOI or immutable versioned URL.
7. Confirm the deposited ZIP's SHA-256 against `DEPOSIT_PACKAGE_SHA256.txt`, which
   is distributed beside the ZIP rather than inside it.

Do not unzip and selectively upload files unless the repository preserves the
directory structure and all checksums. Never edit numerical outputs after
deposition; create a new archive version if a correction is required.
