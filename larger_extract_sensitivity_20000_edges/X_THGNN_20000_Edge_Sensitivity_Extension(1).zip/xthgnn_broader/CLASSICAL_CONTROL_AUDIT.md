# Classical-Control Feature Audit

## Scope

The 120 classical-control runs comprise logistic regression, random forest, and histogram gradient boosting across four datasets and ten prespecified seeds. They are diagnostic comparators, not implementations of named external security systems.

## Feature lineage

The node-control inputs are the same label-independent structural features used by the executable graph builder: log in-degree, log out-degree, log total degree, directional imbalance, normalized mean event position, relation diversity, and one-hot node type. The builder explicitly excludes `edge_label`, `node_label`, `src_node_label`, `dst_node_label`, and `campaign_label` from the input matrix. Preprocessing is fitted on the chronological training partition, validation data select the F1 threshold, and the held-out chronological test partition supplies the reported metrics.

## TRACE result

Logistic regression achieved node F1 = 1.000 and AUROC = 1.000 on the fixed 20,000-edge TRACE extract for all ten runs. The audit found no direct use of label-derived input columns. Because the extract was created with class-aware sampling and does not preserve natural prevalence, the result is interpreted as evidence that this particular retained TRACE sample is structurally separable. It is not evidence of perfect operational detection and reinforces the manuscript's warning that fixed-extract conclusions are not deployment claims.

## Reporting rule

All classical-control results are retained in `baselines/` and summarized in `analysis/classical_control_summary_20000.csv`. They should be reported alongside the graph-reference results and must not be omitted when describing the executed extension.
