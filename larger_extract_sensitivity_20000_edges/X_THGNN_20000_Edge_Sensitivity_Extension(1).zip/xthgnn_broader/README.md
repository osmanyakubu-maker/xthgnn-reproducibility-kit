# X-THGNN 20,000-Edge Sensitivity Extension

Package revision: 1.1 (classical-control disclosure and self-contained cross-scale analysis)

This package records the larger-extract sensitivity experiment added after the locked Version 2 study. It preserves the original Version 2 evidence archive and evaluates the same four public preprocessed datasets at 20,000 retained edges per extract.

## Executed scope

- Datasets: CADETS, THEIA, TRACE, and StreamSpot.
- Extraction seed: 20260821.
- Training seeds: 11, 22, 33, 44, 55, 66, 77, 88, 99, and 110.
- X-THGNN: 40 full-model runs under the locked Version 2 hyperparameters.
- Graph references: 160 runs covering GCN, GAT, Temporal-GAT, and R-GCN.
- Classical diagnostic controls: 120 runs covering logistic regression, random forest, and histogram gradient boosting.
- Primary outcome: source-label-anchored entity/node F1.
- Secondary outputs: node AUROC and AUPRC, derived edge and evaluation-subgraph metrics, explanation diagnostics, robustness stress tests, and optimization histories.

## Directory guide

- `normalized/`: new 20,000-edge normalized inputs and extraction sidecars.
- `runs/`: X-THGNN seed-level configurations, histories, predictions, checkpoints, explanations, and robustness outputs.
- `graph_baselines/`: matched graph-reference seed-level outputs.
- `baselines/`: classical diagnostic controls.
- `summary/`: X-THGNN seed-level and aggregate summaries.
- `analysis/`: cross-scale comparisons, graph-reference comparisons, and the machine-readable extension summary.
- `provenance/`: source archive hashes, runtime information, and the package manifest.
- `RUN_COMMANDS.md`: executable commands for regenerating the full-model, graph-reference, classical-control, and aggregate outputs with the code in Online Resource 1.
- `CLASSICAL_CONTROL_AUDIT.md`: feature-lineage audit and interpretation of the classical-control results.

## Classical-control disclosure

The classical controls are reported as transparent diagnostic comparators. Logistic regression obtained node F1 = 1.000 on the fixed TRACE extract. The feature-lineage audit found no direct label-derived input features: node inputs use structural counts, temporal position, relation diversity, and node type; scalers and vocabularies are fitted on the training partition only. The perfect TRACE result therefore indicates strong separability in this fixed class-aware extract and must not be interpreted as natural-prevalence or deployment performance.

## Re-execution

The package is self-contained for regenerating the extension statistics through `python analyze_extension.py`. Model retraining uses the executable Version 2 code and locked configuration supplied in Online Resource 1; the exact invocations and expected directory layout are recorded in `RUN_COMMANDS.md`.

## Interpretation boundary

This is a larger fixed-extract sensitivity analysis. It does not establish full-release accuracy, natural-prevalence calibration, cross-organization generalization, operational throughput, or deployment readiness. The TRACE node-F1 decline at 20,000 edges is retained and reported rather than tuned away.
