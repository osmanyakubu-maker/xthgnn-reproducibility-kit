# X-THGNN 20,000-Edge Extension Commands

Run these commands from the root of this extension package. Place the public Version 2 evidence archive beside it as `../X_THGNN_Evidence_Archive_v2`, or change `V2_ROOT` to its actual location.

```bash
V2_ROOT=../X_THGNN_Evidence_Archive_v2
SEEDS="11 22 33 44 55 66 77 88 99 110"
python -m pip install -r requirements-extension.txt
```

## Full X-THGNN runs

Repeat for each dataset and seed. The example below is the CADETS seed-11 run.

```bash
python "$V2_ROOT/code/X_THGNN_Reproduction_v3.py" train \
  --events normalized/cadets_20000.csv \
  --config "$V2_ROOT/configuration/manuscript_config_v4.yaml" \
  --output runs/cadets/seed_11 \
  --seed 11 \
  --device cpu \
  --max-epochs 50
```

## Graph-reference runs

Repeat for `gcn`, `gat`, `temporal_gat`, and `rgcn`, every dataset, and every seed.

```bash
python "$V2_ROOT/code/run_graph_baselines_v2.py" \
  --events normalized/cadets_20000.csv \
  --protocol "$V2_ROOT/configuration/manuscript_config_v4.yaml" \
  --output graph_baselines/cadets/gcn/seed_11 \
  --model gcn \
  --seed 11
```

## Classical diagnostic controls

Run once per dataset; the command executes logistic regression, random forest, and histogram gradient boosting for all ten seeds.

```bash
python "$V2_ROOT/code/X_THGNN_Reproduction_v3.py" baseline \
  --events normalized/cadets_20000.csv \
  --output baselines/cadets \
  --seeds $SEEDS \
  --train-fraction 0.8 \
  --validation-fraction 0.1
```

## Aggregate statistics

The package includes the seed-level 5,000-edge metrics required for the paired cross-scale analysis.

```bash
python analyze_extension.py
```

Verify the packaged files after regeneration:

```bash
sha256sum -c MANIFEST.sha256
```
