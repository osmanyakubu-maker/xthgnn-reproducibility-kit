#!/usr/bin/env python3
"""Aggregate the 20,000-edge X-THGNN sensitivity extension."""

from __future__ import annotations

import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


ROOT = Path(__file__).resolve().parent
FIVE_THOUSAND_METRICS = ROOT / "analysis" / "xthgnn_full_seed_metrics_5000.csv"
DATASETS = ["cadets", "theia", "trace", "streamspot"]
MODELS = ["gcn", "gat", "temporal_gat", "rgcn"]


def exact_sign_flip(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    observed = abs(float(values.mean()))
    permutations = [
        abs(float(np.mean(values * np.asarray(signs))))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(permutations) >= observed - 1e-15))


def paired_summary(values: np.ndarray) -> dict:
    values = np.asarray(values, dtype=float)
    mean = float(values.mean())
    sd = float(values.std(ddof=1))
    half = float(stats.t.ppf(0.975, len(values) - 1) * sd / np.sqrt(len(values))) if sd else 0.0
    return {
        "mean_difference": mean,
        "ci95_low": mean - half,
        "ci95_high": mean + half,
        "effect_dz": mean / sd if sd else None,
        "exact_sign_flip_p": exact_sign_flip(values),
    }


def holm(frame: pd.DataFrame, p_column: str, group_columns: list[str] | None = None) -> pd.Series:
    adjusted = pd.Series(index=frame.index, dtype=float)
    groups = [(None, frame)] if not group_columns else frame.groupby(group_columns, sort=False)
    for _, block in groups:
        values = block[p_column].to_numpy(float)
        order = np.argsort(values)
        running = 0.0
        for rank, local_index in enumerate(order):
            running = max(running, min(1.0, (len(values) - rank) * values[local_index]))
            adjusted.loc[block.index[local_index]] = running
    return adjusted


def load_graph_baselines() -> pd.DataFrame:
    rows = []
    for path in sorted((ROOT / "graph_baselines").glob("*/*/seed_*/metrics.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        payload["dataset"] = path.parents[2].name
        rows.append(payload)
    return pd.DataFrame(rows)


def load_classical_controls() -> pd.DataFrame:
    rows = []
    for path in sorted((ROOT / "baselines").glob("*/baseline_seed_metrics.csv")):
        frame = pd.read_csv(path)
        frame.insert(0, "dataset", path.parent.name)
        rows.append(frame)
    return pd.concat(rows, ignore_index=True)


def main() -> None:
    out = ROOT / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    x20 = pd.read_csv(ROOT / "summary" / "seed_metrics.csv")
    x5 = pd.read_csv(FIVE_THOUSAND_METRICS).rename(
        columns={"f1": "node_f1", "auroc": "node_auroc", "auprc": "node_auprc"}
    )
    graph = load_graph_baselines()
    classical = load_classical_controls()
    graph.to_csv(out / "graph_baseline_seed_metrics_20000.csv", index=False)
    classical.to_csv(out / "classical_control_seed_metrics_20000.csv", index=False)

    classical_summary = (
        classical.groupby(["dataset", "model"], sort=False)["node_f1"]
        .agg(["count", "mean", "std"])
        .reset_index()
        .rename(columns={"count": "n_seeds", "std": "sd"})
    )
    classical_summary.to_csv(out / "classical_control_summary_20000.csv", index=False)

    model_rows = []
    for dataset in DATASETS:
        x = x20[x20["dataset"] == dataset]["node_f1"]
        model_rows.append({"dataset": dataset, "model": "xthgnn", "mean": x.mean(), "sd": x.std(ddof=1)})
        for model in MODELS:
            values = graph[(graph["dataset"] == dataset) & (graph["model"] == model)]["f1"]
            model_rows.append({"dataset": dataset, "model": model, "mean": values.mean(), "sd": values.std(ddof=1)})
    pd.DataFrame(model_rows).to_csv(out / "node_f1_model_summary_20000.csv", index=False)

    scale_rows = []
    for dataset in DATASETS:
        merged = x20[x20["dataset"] == dataset][["seed", "node_f1"]].merge(
            x5[x5["dataset"] == dataset][["seed", "node_f1"]],
            on="seed", suffixes=("_20000", "_5000"),
        )
        row = {
            "dataset": dataset,
            "mean_f1_5000": merged["node_f1_5000"].mean(),
            "mean_f1_20000": merged["node_f1_20000"].mean(),
            **paired_summary((merged["node_f1_20000"] - merged["node_f1_5000"]).to_numpy()),
        }
        scale_rows.append(row)
    scale = pd.DataFrame(scale_rows)
    scale["holm_p_across_four_datasets"] = holm(scale, "exact_sign_flip_p")
    scale.to_csv(out / "paired_scale_comparisons.csv", index=False)

    comparison_rows = []
    for dataset in DATASETS:
        x = x20[x20["dataset"] == dataset][["seed", "node_f1"]]
        for model in MODELS:
            reference = graph[(graph["dataset"] == dataset) & (graph["model"] == model)][["seed", "f1"]]
            merged = x.merge(reference, on="seed")
            comparison_rows.append({
                "dataset": dataset,
                "reference": model,
                **paired_summary((merged["node_f1"] - merged["f1"]).to_numpy()),
            })
    comparisons = pd.DataFrame(comparison_rows)
    comparisons["holm_p_across_16_comparisons"] = holm(comparisons, "exact_sign_flip_p")
    comparisons.to_csv(out / "paired_graph_reference_comparisons_20000.csv", index=False)

    report = {
        "package_revision": "1.1",
        "scope": "four 20,000-edge public MAGIC/StreamSpot extracts; ten seeds; locked Version 2 model and graph-reference protocol",
        "xthgnn_runs": int(len(x20)),
        "graph_reference_runs": int(len(graph)),
        "classical_control_runs": int(len(classical)),
        "classical_control_node_f1": classical_summary.to_dict(orient="records"),
        "scale_comparisons": scale.to_dict(orient="records"),
        "significant_graph_reference_comparisons_after_holm": comparisons[
            comparisons["holm_p_across_16_comparisons"] < 0.05
        ].to_dict(orient="records"),
        "boundary": "Sensitivity analysis on fixed class-aware extracts; not full-release or natural-prevalence deployment evaluation.",
    }
    (out / "extension_summary.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
